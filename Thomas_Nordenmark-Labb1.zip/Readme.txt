Hej Örjan,

Gick visst lite snabbt med kodandet förra gången. Men nu har jag fått det att fungera cirkulärt
tror jag. Så att även dequeue fungerar då man går tillbaka till index 0 i arrayen.

Trevlig helg!

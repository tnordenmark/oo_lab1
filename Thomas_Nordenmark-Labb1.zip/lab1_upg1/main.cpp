/*
* Filnamn: main.cpp
* Labb nr: Labb 1 uppgift 1
* Studentens namn: Thomas Nordenmark
*/

#include "testapp.h"

using namespace std;

int main()
{
    // Create main application object
    TestApp app;

    // Run application
    app.run();

    return 0;
}
